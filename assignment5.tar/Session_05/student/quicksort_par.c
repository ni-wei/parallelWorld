#include <omp.h>

#include "quicksort.h"
#include "helper.h"

void quicksort(int *a, int left, int right, int num_threads)
{

	// insert your code here
}
