#include <pthread.h>
#include <stdlib.h>

#include "histogram.h"

void get_histogram(unsigned int nBlocks,
		   						 block_t *blocks,
		   						 histogram_t histogram,
		   						 unsigned int num_threads) {

	// insert your code here

}
