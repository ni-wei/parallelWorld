#ifndef QUICKSORT_H_
#define QUICKSORT_H_

void quicksort(int *a, int left, int right, int num_threads);

#endif /* QUICKSORT_H_ */
