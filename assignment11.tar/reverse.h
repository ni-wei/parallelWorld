#ifndef REVERSE_H_
#define REVERSE_H_

void reverse(char *str, int strlen);
int r_displs(int rank, int np, int *counts);

#endif /* REVERSE_H_ */
