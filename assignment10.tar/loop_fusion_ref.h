#ifndef LOOP_FUSION_REF_H_
#define LOOP_FUSION_REF_H_

void compute_ref(unsigned long **a, unsigned long **b, unsigned long **c, unsigned long **d, int N, int num_threads);


#endif /* LOOP_FUSION_REF_H_ */
