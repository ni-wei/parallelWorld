#ifndef LOOP_FUSION_H_
#define LOOP_FUSION_H_


void compute(unsigned long **a, unsigned long **b, unsigned long **c, unsigned long **d, int N, int num_threads);

#endif /* LOOP_FUSION_H_ */
