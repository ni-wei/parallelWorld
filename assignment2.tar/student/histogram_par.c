#include <pthread.h>

#include "histogram.h"

void get_histogram(char *buffer,
		   			 unsigned int* histogram,
		   			 unsigned int num_threads,
						 unsigned int chunk_size) {

	// enter your code here
}
