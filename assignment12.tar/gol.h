#ifndef GOL_H_
#define GOL_H_

unsigned int gol(unsigned char *grid, unsigned int dim_x, unsigned int dim_y, unsigned int time_steps);

#endif /* GOL_H_ */
